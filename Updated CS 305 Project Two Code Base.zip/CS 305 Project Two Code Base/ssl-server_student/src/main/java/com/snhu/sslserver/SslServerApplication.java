package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}

@RestController
class ServerController {
 
	private static final Logger logger = LoggerFactory.getLogger(ServerController.class);
	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

	private String getHash(String input) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] messageDigestSHA256 = messageDigest.digest(input.getBytes());
			return bytesToHex(messageDigestSHA256);
		} catch (NoSuchAlgorithmException e) {
			logger.error("Error while generating SHA-256 hash", e);
			return "Error generating hash";
		}
	}

	public static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = HEX_ARRAY[v >>> 4];
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars);
	}

	@RequestMapping("/hash")
	public String myHash() {
		String data = "Jeremia Lim – CS-305 Checksum Verification";
		String hash = getHash(data);
		return "<h2>Checksum Verification</h2>"
				+ "<p><strong>Name:</strong> Jeremia Lim</p>"
				+ "<p><strong>Data:</strong> " + data + "</p>"
				+ "<p><strong>Hash Algorithm:</strong> SHA-256</p>"
				+ "<p><strong>Checksum:</strong> " + hash + "</p>";
	}
}
